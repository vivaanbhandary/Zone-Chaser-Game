package model;
// Enemies will deal damage to the player on contact or shoot projectiles

public class Enemy {
}
