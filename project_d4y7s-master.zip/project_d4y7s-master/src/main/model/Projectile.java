package model;

// a projectile deals damage to the player on contact

public class Projectile {
}
